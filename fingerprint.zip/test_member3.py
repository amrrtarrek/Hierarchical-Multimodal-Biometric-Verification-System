import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pytest
from fingerprint.gabor_extractor import GaborFingerprintExtractor
from fingerprint.preprocess import preprocess
from fingerprint.train_fingerprint import FingerprintModel
from command.command_classifier import CommandClassifier, COMMANDS, speaker_invariance_cv
from rbac_engine import RBACEngine, PermissionDenied, LiveCommandListener


def fake_prints(n, seed=0):
    rng = np.random.default_rng(seed)
    return [rng.integers(0, 256, (150, 140), dtype=np.uint8) for _ in range(n)]


def test_preprocess_shapes():
    for b in (False, True):
        out = preprocess(fake_prints(1)[0], binarize=b)
        assert out.shape == (128, 128) and out.dtype == np.uint8
    assert set(np.unique(preprocess(fake_prints(1)[0], True))) <= {0, 255}


def test_gabor_shape_dtype():
    X = GaborFingerprintExtractor().fit().transform([preprocess(i) for i in fake_prints(6)])
    assert X.shape == (6, 64) and X.dtype == np.float32 and np.isfinite(X).all()


def test_fingerprint_model_probs():
    rng = np.random.default_rng(1)
    X = rng.normal(size=(60, 64)).astype(np.float32)
    y = np.repeat([0, 1, 2], 20)
    X[y == 1] += 2
    X[y == 2] -= 2
    p = FingerprintModel().fit(X, y).predict_proba(X)
    assert p.shape == (60, 3) and np.allclose(p.sum(1), 1)


def command_data():
    rng = np.random.default_rng(2)
    y = np.tile([0, 1, 2], 40)
    spk = np.repeat(np.arange(8), 15)
    X = rng.normal(size=(120, 46))
    X[:, :3] += np.eye(3)[y] * 4
    return X, y, spk


def test_command_classifier_speaker_invariant():
    X, y, spk = command_data()
    assert speaker_invariance_cv(X, y, spk) > 0.9
    assert CommandClassifier().fit(X, y).predict(X[:3]).tolist() == [COMMANDS[i] for i in y[:3]]


@pytest.mark.parametrize("ident,cmd,ok", [
    (1, "Unlock System", True), (1, "Report Status", True), (1, "Terminate Session", True),
    (2, "Unlock System", True), (2, "Report Status", True), (2, "Terminate Session", False),
    (3, "Report Status", True), (3, "Unlock System", False), (3, "Terminate Session", False),
    (4, "Report Status", True), (4, "Unlock System", False),
    (0, "Report Status", False), (0, "Unlock System", False), (0, "Terminate Session", False),
    (99, "Report Status", False),
])
def test_rbac_matrix(ident, cmd, ok):
    e = RBACEngine()
    if ok:
        assert e.execute(ident, cmd)
    else:
        with pytest.raises(PermissionDenied):
            e.execute(ident, cmd)


def test_low_confidence_denied():
    with pytest.raises(PermissionDenied):
        RBACEngine().execute(1, "Unlock System", command_conf=0.2)


def test_live_listener_escalation():
    X, y, _ = command_data()
    l = LiveCommandListener(CommandClassifier().fit(X, y), feature_fn=lambda buf: buf)
    term = X[y == 2][0]
    assert l.handle(3, term)["status"] == "PERMISSION_DENIED"
    assert l.handle(0, term)["status"] == "PERMISSION_DENIED"
    assert l.handle(1, term)["status"] == "EXECUTED"
