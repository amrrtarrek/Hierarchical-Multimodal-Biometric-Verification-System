"""Task 3.1: fingerprint conditioning (128x128, CLAHE, optional Otsu)."""
import glob
import os
import cv2
import numpy as np

SIZE = 128


def preprocess(img, binarize=False):
    """Gray -> 128x128 -> CLAHE(clip=2.0, tile=8x8) -> optional Otsu. Returns uint8."""
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img = cv2.resize(img, (SIZE, SIZE), interpolation=cv2.INTER_AREA)
    img = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(img)
    if binarize:
        _, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return img


def load_dataset(root, binarize=False):
    """Expects root/<class_id>/*.(png|jpg|bmp|tif). Class 0 = impostor folder '0'."""
    X, y = [], []
    for cls in sorted(os.listdir(root)):
        folder = os.path.join(root, cls)
        if not (os.path.isdir(folder) and cls.isdigit()):
            continue
        for ext in ("png", "jpg", "jpeg", "bmp", "tif"):
            for path in glob.glob(os.path.join(folder, f"*.{ext}")):
                img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
                if img is None:
                    raise IOError(f"Unreadable image: {path}")
                X.append(preprocess(img, binarize))
                y.append(int(cls))
    return np.array(X, dtype=np.uint8), np.array(y, dtype=int)


def augment(img, rng):
    """Light augmentation for the tiny personal set: rotation, shift, brightness."""
    h, w = img.shape
    M = cv2.getRotationMatrix2D((w / 2, h / 2), rng.uniform(-10, 10), 1.0)
    M[:, 2] += rng.uniform(-6, 6, size=2)
    out = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    return np.clip(out.astype(np.float32) * rng.uniform(0.85, 1.15), 0, 255).astype(np.uint8)
