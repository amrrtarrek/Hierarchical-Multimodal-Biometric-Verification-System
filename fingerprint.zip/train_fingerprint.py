"""Task 3.2 (steps 4-5): standalone Fingerprint SVM (RBF + Platt), leakage-safe CV.

Usage: python -m fingerprint.train_fingerprint data/fingerprint [--out models/fingerprint]
Folder layout: data/fingerprint/<class_id>/*.png   (0 = impostor, 1..N genuine)
"""
import argparse
import itertools
import os
import sys
import joblib
import numpy as np
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from _compat import BaseBiometricModel
from fingerprint.gabor_extractor import GaborFingerprintExtractor
from fingerprint.preprocess import augment, load_dataset


class FingerprintModel(BaseBiometricModel):
    """Scaler + RBF SVC with built-in Platt scaling (probability=True)."""

    def __init__(self, C=10.0, gamma="scale"):
        self.C, self.gamma = C, gamma
        self.pipe = make_pipeline(
            StandardScaler(),
            SVC(kernel="rbf", C=C, gamma=gamma, probability=True, random_state=0))

    def fit(self, X, y):
        self.pipe.fit(X, y)
        return self

    def predict(self, X):
        return self.pipe.predict(X)

    def predict_proba(self, X):
        return self.pipe.predict_proba(X)

    @property
    def classes_(self):
        return self.pipe.classes_


def augmented_features(extractor, imgs, labels, n_aug, rng, genuine_only=True):
    """Augment TRAIN images only (after the split) so no copy of a test sample leaks."""
    out_i, out_y = list(imgs), list(labels)
    for im, lb in zip(imgs, labels):
        if genuine_only and lb == 0:
            continue
        for _ in range(n_aug):
            out_i.append(augment(im, rng))
            out_y.append(lb)
    return extractor.transform(out_i), np.array(out_y)


def cross_validate(imgs, y, C, gamma, n_aug=5, seed=0):
    ext = GaborFingerprintExtractor()
    counts = np.bincount(y)
    k = int(max(2, min(5, counts[counts > 0].min())))
    rng = np.random.default_rng(seed)
    scores = []
    for tr, te in StratifiedKFold(k, shuffle=True, random_state=seed).split(imgs, y):
        Xtr, ytr = augmented_features(ext, imgs[tr], y[tr], n_aug, rng)
        m = FingerprintModel(C, gamma).fit(Xtr, ytr)
        scores.append(f1_score(y[te], m.predict(ext.transform(imgs[te])), average="macro"))
    return float(np.mean(scores))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data")
    ap.add_argument("--out", default="models/fingerprint")
    ap.add_argument("--n_aug", type=int, default=5)
    a = ap.parse_args()

    # Compare CLAHE-only vs Otsu-binarised input to the Gabor bank; keep the better.
    best = (-1, None)
    for binarize in (False, True):
        imgs, y = load_dataset(a.data, binarize)
        for C, g in itertools.product((1.0, 10.0, 100.0), ("scale", "auto", 0.01)):
            s = cross_validate(imgs, y, C, g, a.n_aug)
            print(f"binarize={binarize} C={C} gamma={g} macroF1={s:.3f}")
            if s > best[0]:
                best = (s, (binarize, C, g))
    _, (binarize, C, g) = best
    print("Best:", best)

    imgs, y = load_dataset(a.data, binarize)
    ext = GaborFingerprintExtractor()
    X, yy = augmented_features(ext, imgs, y, a.n_aug, np.random.default_rng(0))
    model = FingerprintModel(C, g).fit(X, yy)
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, "best_fingerprint_model.joblib")
    joblib.dump({"extractor": ext, "model": model, "binarize": binarize}, path)
    print("Saved", path)


if __name__ == "__main__":
    main()
