"""Task 3.3 (steps 2-4): identity-governed RBAC + live command handling."""
from dataclasses import dataclass
from command.command_classifier import COMMANDS

UNLOCK, STATUS, TERMINATE = COMMANDS
IMPOSTOR = 0

ROLES = {1: "Admin", 2: "Operator", 3: "Auditor", 4: "Auditor"}
POLICY = {
    "Admin": {UNLOCK, STATUS, TERMINATE},
    "Operator": {UNLOCK, STATUS},
    "Auditor": {STATUS},
}


class PermissionDenied(Exception):
    """Raised on any unauthorised command."""


@dataclass
class Decision:
    allowed: bool
    identity: int
    role: str
    command: str
    reason: str


class RBACEngine:
    def __init__(self, handlers=None, min_command_conf=0.5):
        self.min_command_conf = min_command_conf
        self.handlers = handlers or {
            UNLOCK: lambda: "System unlocked.",
            STATUS: lambda: "Status: all systems nominal.",
            TERMINATE: lambda: "Session terminated.",
        }

    def check(self, identity, command, command_conf=1.0) -> Decision:
        role = ROLES.get(identity, "None")
        if identity == IMPOSTOR or identity not in ROLES:
            return Decision(False, identity, role, command, "Unverified/impostor: denied on all commands")
        if command not in COMMANDS:
            return Decision(False, identity, role, command, "Unknown command")
        if command_conf < self.min_command_conf:
            return Decision(False, identity, role, command, "Command confidence too low")
        if command not in POLICY[role]:
            return Decision(False, identity, role, command, f"{role} is not authorised for '{command}'")
        return Decision(True, identity, role, command, "Authorised")

    def execute(self, identity, command, command_conf=1.0):
        d = self.check(identity, command, command_conf)
        if not d.allowed:
            raise PermissionDenied(f"PERMISSION DENIED: {d.reason}")
        return self.handlers[command]()


class LiveCommandListener:
    """Glue to Member 2's mic stream. Their queue yields (speaker_id, audio_buffer)
    where audio_buffer is the 1.5 s / 24,000-sample pre-emphasised clip.
    `feature_fn` is Member 2's 46D extractor.transform for a single clip."""

    def __init__(self, command_model, feature_fn, engine=None):
        self.cmd, self.feature_fn, self.engine = command_model, feature_fn, engine or RBACEngine()

    def handle(self, speaker_id, audio_buffer):
        command, conf = self.cmd.predict_with_confidence(self.feature_fn(audio_buffer))
        try:
            msg = self.engine.execute(speaker_id, command, conf)
            return {"status": "EXECUTED", "identity": speaker_id, "command": command, "confidence": conf, "result": msg}
        except PermissionDenied as e:
            return {"status": "PERMISSION_DENIED", "identity": speaker_id, "command": command, "confidence": conf, "result": str(e)}

    def run(self, audio_queue, stop_event):
        import queue
        while not stop_event.is_set():
            try:
                spk, buf = audio_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            print(self.handle(spk, buf))
