"""Task 3.2: 2D Gabor filter bank -> 64D feature vector."""
import cv2
import numpy as np
from _compat import BaseFeatureExtractor

WAVELENGTHS = (4, 8, 16, 24)
ORIENTATIONS = tuple(k * np.pi / 8 for k in range(8))


class GaborFingerprintExtractor(BaseFeatureExtractor):
    """4 wavelengths x 8 orientations = 32 kernels; per response mean & std -> 64D.
    Layout: [mu1, sigma1, mu2, sigma2, ..., mu32, sigma32]."""

    def __init__(self, gamma=0.5, psi=0.0, size=128):
        self.size = size
        self.kernels = []
        for lam in WAVELENGTHS:
            sigma = 0.56 * lam                      # ~1 octave bandwidth
            k = min(2 * int(3 * sigma) + 1, 61)     # odd, capped for 128px images
            for theta in ORIENTATIONS:
                self.kernels.append(
                    cv2.getGaborKernel((k, k), sigma, theta, lam, gamma, psi, ktype=cv2.CV_32F))

    def fit(self, samples=None):
        return self  # stateless

    def _one(self, img):
        if img.ndim == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        if img.shape != (self.size, self.size):
            img = cv2.resize(img, (self.size, self.size), interpolation=cv2.INTER_AREA)
        img = img.astype(np.float32) / 255.0
        feats = []
        for ker in self.kernels:
            r = cv2.filter2D(img, cv2.CV_32F, ker, borderType=cv2.BORDER_REFLECT)
            feats += [r.mean(), r.std()]
        return feats

    def transform(self, samples) -> np.ndarray:
        X = np.array([self._one(s) for s in samples], dtype=np.float32)
        if not np.isfinite(X).all():
            raise ValueError("Non-finite Gabor features")
        return X  # (N, 64)
