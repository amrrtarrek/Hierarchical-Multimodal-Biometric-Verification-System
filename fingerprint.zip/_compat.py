"""Use Member 4's interfaces when present; fall back to identical stubs so
this branch runs standalone. Remove the fallback once interfaces.py is merged."""
try:
    from src.interfaces import BaseFeatureExtractor, BaseBiometricModel  # noqa: F401
except ImportError:
    from abc import ABC, abstractmethod
    import numpy as np

    class BaseFeatureExtractor(ABC):
        @abstractmethod
        def fit(self, samples): ...
        @abstractmethod
        def transform(self, samples) -> np.ndarray: ...

    class BaseBiometricModel(ABC):
        @abstractmethod
        def fit(self, X, y): ...
        @abstractmethod
        def predict(self, X): ...
        @abstractmethod
        def predict_proba(self, X): ...
