"""Task 3.3 (step 1): speaker-invariant isolated-word command recogniser."""
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GroupKFold
from _compat import BaseBiometricModel

COMMANDS = ("Unlock System", "Report Status", "Terminate Session")


class CommandClassifier(BaseBiometricModel):
    """Random Forest on 46D acoustic vectors; labels are command indices 0..2
    (or the command strings). Trained across speakers so it ignores who is talking."""

    def __init__(self, n_estimators=200, max_depth=15, seed=0):
        self.rf = RandomForestClassifier(
            n_estimators=n_estimators, max_depth=max_depth, random_state=seed, n_jobs=-1)

    def fit(self, X, y):
        y = [COMMANDS.index(v) if isinstance(v, str) else int(v) for v in y]
        self.rf.fit(X, y)
        return self

    def predict(self, X):
        return np.array([COMMANDS[i] for i in self.rf.predict(X)])

    def predict_proba(self, X):
        return self.rf.predict_proba(X)

    def predict_with_confidence(self, x):
        p = self.predict_proba(np.atleast_2d(x))[0]
        i = int(p.argmax())
        return COMMANDS[i], float(p[i])


def speaker_invariance_cv(X, y, speakers, n_splits=3):
    """Leave-speakers-out CV: accuracy on speakers never seen in training."""
    y = np.array(y)
    accs = []
    for tr, te in GroupKFold(n_splits).split(X, y, groups=speakers):
        pred = CommandClassifier().fit(X[tr], y[tr]).predict(X[te])
        accs.append(accuracy_score([COMMANDS[i] for i in y[te]], pred))
    return float(np.mean(accs))
